package Text;

public class String {

}
