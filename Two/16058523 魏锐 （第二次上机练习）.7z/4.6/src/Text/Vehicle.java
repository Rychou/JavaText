package Text;

public class Vehicle {
		double load;
		double maxLoad;
		public Vehicle(double max_load){
			maxLoad = max_load;
		}
		public double getLoad(){
			return load;
		}
		public double getMaxLoad(){
			return maxLoad;
		}
	

}
